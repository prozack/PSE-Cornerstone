import PageManager from './page-manager';

export default class Blog extends PageManager {}
// This is a test comment.
